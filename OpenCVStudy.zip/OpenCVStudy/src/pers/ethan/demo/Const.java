package pers.ethan.demo;

/**
 * desc:
 * Created by huangzhe on 2017/4/21.
 */
public class Const {
    public static String IMAGE_FILE_PATH = "/Users/huangzhe/Documents/MyCode/Study/Java/OpenCVStudy/image/";
    public static String RESOURCE_FILE_PATH = "/Users/huangzhe/Documents/MyCode/Study/Java/OpenCVStudy/resources/";
}
