package pers.ethan.httpclient;

/**
 * Hello world!
 *
 */
public class HttpClient 
{
    public static void main( String[] args )
    {
    	
    }
    
}
