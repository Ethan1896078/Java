package pers.ethan.socketserver;

public class UdpServer {
	public static void main(String[] args) {
		
	}
}
