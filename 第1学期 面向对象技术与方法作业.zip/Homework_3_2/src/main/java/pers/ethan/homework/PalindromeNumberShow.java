package pers.ethan.homework;

public interface PalindromeNumberShow {
	public void showPalindromeNumber(int endNumber);
}
