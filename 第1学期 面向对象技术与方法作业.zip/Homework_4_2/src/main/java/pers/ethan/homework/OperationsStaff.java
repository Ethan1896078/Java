package pers.ethan.homework;

public class OperationsStaff extends Staff{

	@Override
	public void work() {
		System.out.println("...上线...");
	}

}
