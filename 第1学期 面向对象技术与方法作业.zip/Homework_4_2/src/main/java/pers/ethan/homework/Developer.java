package pers.ethan.homework;

public class Developer extends Staff{

	@Override
	public void work() {
		System.out.println("...开发软件...");
	}

}
