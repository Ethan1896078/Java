package pers.ethan.homework;

public interface Adjustable {
	/**
	 * desc:调节
	 * <p>创建人：huangzhe , 2016年5月20日下午2:05:34</p>
	 */
	public void adjust();
}
