package pers.ethan.homework;

public interface Sensable {
	/**
	 * desc:传感
	 * <p>创建人：huangzhe , 2016年5月20日下午2:11:49</p>
	 * @param value
	 */
	public void sense(double value);
	
}
