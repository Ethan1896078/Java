package pers.ethan.homework;

public class TemperatureAdjuster implements Adjustable{

	public void adjust() {
		System.out.println("温度调节器正在调节温度...");
		System.out.println();
	}
	
}
