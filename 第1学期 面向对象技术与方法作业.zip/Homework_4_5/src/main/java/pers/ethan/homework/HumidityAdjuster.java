package pers.ethan.homework;

public class HumidityAdjuster implements Adjustable{

	public void adjust() {
		System.out.println("湿度调节器正在调节湿度...");
		System.out.println();
	}
	
}
